-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 05, 2010 at 07:22 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_allow`
--

CREATE TABLE IF NOT EXISTS `zre_acl_allow` (
  `acl_allow_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_allow_id`),
  KEY `name_id` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `zre_acl_allow`
--

INSERT INTO `zre_acl_allow` (`acl_allow_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:9:{i:0;s:20:"administration.index";i:1;s:8:"articles";i:2;s:8:"products";i:3;s:6:"orders";i:4;s:5:"index";i:5;s:4:"logs";i:6;s:14:"administration";i:7;s:5:"users";i:8;s:3:"acl";}', 'a:1:{i:0;s:3:"ALL";}', 'staff'),
(2, 'a:5:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:5:"users";}', 'a:1:{i:0;s:3:"ALL";}', 'editor'),
(3, 'a:13:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:5:"error";i:4;s:8:"products";i:5;s:5:"users";i:6;s:4:"logs";i:7;s:6:"orders";i:8;s:3:"acl";i:9;s:14:"searchSettings";i:10;s:7:"plugins";i:11;s:5:"index";i:12;s:6:"backup";}', 'a:7:{i:0;s:3:"new";i:1;s:4:"view";i:2;s:6:"update";i:3;s:6:"remove";i:4;s:7:"publish";i:5;s:7:"archive";i:6;s:3:"ALL";}', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_article_resource_type`
--

CREATE TABLE IF NOT EXISTS `zre_acl_article_resource_type` (
  `article_resource_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`article_resource_type_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zre_acl_article_resource_type`
--

INSERT INTO `zre_acl_article_resource_type` (`article_resource_type_id`, `type`) VALUES
(3, 'archive'),
(1, 'article'),
(4, 'download'),
(2, 'homepage'),
(5, 'support');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_deny`
--

CREATE TABLE IF NOT EXISTS `zre_acl_deny` (
  `acl_deny_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_deny_id`),
  KEY `name_id` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zre_acl_deny`
--

INSERT INTO `zre_acl_deny` (`acl_deny_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:6:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:7:"plugins";i:5;s:5:"index";}', 'a:1:{i:0;s:4:"view";}', 'guest');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_resource`
--

CREATE TABLE IF NOT EXISTS `zre_acl_resource` (
  `acl_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acl_resource_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `zre_acl_resource`
--

INSERT INTO `zre_acl_resource` (`acl_resource_id`, `name`, `parent`) VALUES
(1, 'administration', NULL),
(2, 'administration.index', 'administration'),
(3, 'articles', 'administration'),
(4, 'error', 'administration'),
(5, 'products', 'administration'),
(6, 'users', 'administration'),
(7, 'logs', 'administration'),
(8, 'orders', 'administration'),
(9, 'acl', 'administration'),
(10, 'searchSettings', 'administration'),
(11, 'plugins', 'administration'),
(12, 'index', NULL),
(13, 'backup', 'administration');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_role`
--

CREATE TABLE IF NOT EXISTS `zre_acl_role` (
  `acl_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parents` text,
  PRIMARY KEY (`acl_role_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zre_acl_role`
--

INSERT INTO `zre_acl_role` (`acl_role_id`, `name`, `parents`) VALUES
(1, 'guest', NULL),
(2, 'staff', 'a:1:{i:0;s:5:"guest";}'),
(3, 'editor', 'a:1:{i:0;s:5:"staff";}'),
(4, 'administrator', NULL),
(5, 'logs', '');

-- --------------------------------------------------------

--
-- Table structure for table `zre_article`
--

CREATE TABLE IF NOT EXISTS `zre_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_container_id` int(11) NOT NULL,
  `resource` text NOT NULL,
  `published` enum('no','yes','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  PRIMARY KEY (`article_id`),
  KEY `article_container_id` (`article_container_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='article info without content.' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `zre_article`
--

INSERT INTO `zre_article` (`article_id`, `article_container_id`, `resource`, `published`, `title`, `description`, `date_created`, `date_modified`, `image`) VALUES
(5, 1, 'home', 'no', 'Hiring freelance PHP developers, need strong OOP skills. Really long title test testing 123.', '<p>Another interesting article.<br></p>', '2010-08-11 22:08:45', '2010-10-03 21:53:21', '/images/dummy.png'),
(6, 1, 'home', 'no', 'Open-source commerce', '<p>A well written, well documented commerce application based on PHP and the Zend Framework.</p><p>Developers may find this open-source web application especially useful in deploying reliable, scalable, and customizable web commerce projects!</p>', '2010-08-11 22:08:45', '2010-10-03 18:25:46', '/images/z.png');

-- --------------------------------------------------------

--
-- Table structure for table `zre_article_container`
--

CREATE TABLE IF NOT EXISTS `zre_article_container` (
  `article_container_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`article_container_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Article containment structure.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zre_article_container`
--

INSERT INTO `zre_article_container` (`article_container_id`, `parent_id`, `title`, `description`, `date`) VALUES
(1, NULL, 'Main', 'The main category', '2010-08-11 22:08:01');

-- --------------------------------------------------------

--
-- Table structure for table `zre_logs`
--

CREATE TABLE IF NOT EXISTS `zre_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders`
--

CREATE TABLE IF NOT EXISTS `zre_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `decision` varchar(32) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` enum('pending','shipped','void','exchanged','refunded','awaiting_return','complete') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`order_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='order records' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_cybersource`
--

CREATE TABLE IF NOT EXISTS `zre_orders_cybersource` (
  `orders_cybersource_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `reason_code` varchar(16) NOT NULL,
  `request_id` varchar(255) NOT NULL,
  `request_token` varchar(255) NOT NULL,
  `currency` varchar(16) NOT NULL,
  `cc_auth_blob` text NOT NULL,
  PRIMARY KEY (`orders_cybersource_id`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders_cybersource`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_products`
--

CREATE TABLE IF NOT EXISTS `zre_orders_products` (
  `order_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`order_product_id`),
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`),
  KEY `unit_price` (`unit_price`,`quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders_products`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_plugin`
--

CREATE TABLE IF NOT EXISTS `zre_plugin` (
  `plugin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `settings` text,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`plugin_id`),
  KEY `name` (`name`,`enabled`,`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zre_plugin`
--

INSERT INTO `zre_plugin` (`plugin_id`, `name`, `enabled`, `settings`, `position`) VALUES
(1, 'Menu_Main', 1, NULL, 'header'),
(2, 'Menu_Search', 0, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `zre_product`
--

CREATE TABLE IF NOT EXISTS `zre_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT NULL,
  `published` enum('yes','no','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  `price` float NOT NULL,
  `weight` float NOT NULL,
  `size` float NOT NULL,
  `allotment` int(11) NOT NULL,
  `pending` int(11) NOT NULL,
  `sold` int(11) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_container_id` (`article_id`),
  KEY `title` (`title`),
  KEY `price` (`price`),
  KEY `weight` (`weight`),
  KEY `size` (`size`),
  KEY `allotment` (`allotment`),
  KEY `pending` (`pending`),
  KEY `sold` (`sold`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zre_product`
--

INSERT INTO `zre_product` (`product_id`, `article_id`, `published`, `title`, `description`, `date_created`, `date_modified`, `image`, `price`, `weight`, `size`, `allotment`, `pending`, `sold`) VALUES
(1, 6, 'yes', 'We host, you sell', 'Simply upload your products to your very own shop hosted with us, and watch it sell. We send you packaging material, and only charge you a small fee for what sells.*\r\n\r\n\r\n* This does not include the required monthly fee for this item.', '2010-08-15 12:17:13', '2010-08-15 12:17:13', '/images/z.png', 39.99, 0, 0, 88, 0, 12),
(2, 6, 'yes', 'Product #2', 'This is another product', '2010-08-26 12:44:25', '2010-08-26 12:44:30', '/images/dummy.png', 12.99, 1, 1, 100, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zre_users`
--

CREATE TABLE IF NOT EXISTS `zre_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User table.' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zre_users`
--

INSERT INTO `zre_users` (`user_id`, `name`, `password`, `creation_date`) VALUES
(1, 'administrator', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-10-05 19:19:33'),
(2, 'testuser', '07b94d935361d049d301794eaa55d2d6', '2010-08-09 21:57:22');

-- --------------------------------------------------------

--
-- Table structure for table `zre_users_profile`
--

CREATE TABLE IF NOT EXISTS `zre_users_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `country` text NOT NULL,
  `state_province` text NOT NULL,
  `city` text NOT NULL,
  `zipcode` text NOT NULL,
  `telephone_primary` text NOT NULL,
  `telephone_secondary` text,
  `role` enum('administrator','editor','staff','guest') NOT NULL DEFAULT 'guest',
  PRIMARY KEY (`user_profile_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User profile information.' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zre_users_profile`
--

INSERT INTO `zre_users_profile` (`user_profile_id`, `user_id`, `email`, `date_of_birth`, `first_name`, `last_name`, `country`, `state_province`, `city`, `zipcode`, `telephone_primary`, `telephone_secondary`, `role`) VALUES
(1, 1, 'webmaster@localhost.com', '1970-01-01', 'Test', 'User', 'US', 'CA', 'Vallejo', '94590', '7075551234', '', 'administrator'),
(2, 2, 'testuser@example.com', '1985-08-09', 'Test', 'User', 'US', 'CA', 'Vallejo', '94591', '707-555-1234', NULL, 'editor');
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
