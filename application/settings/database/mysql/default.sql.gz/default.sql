-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 08, 2010 at 12:14 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_allow`
--

CREATE TABLE IF NOT EXISTS `zre_acl_allow` (
  `acl_allow_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_allow_id`),
  KEY `name_id` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `zre_acl_allow`
--

INSERT INTO `zre_acl_allow` (`acl_allow_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:9:{i:0;s:20:"administration.index";i:1;s:8:"articles";i:2;s:8:"products";i:3;s:6:"orders";i:4;s:5:"index";i:5;s:4:"logs";i:6;s:14:"administration";i:7;s:5:"users";i:8;s:3:"acl";}', 'a:1:{i:0;s:3:"ALL";}', 'staff'),
(2, 'a:5:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:5:"users";}', 'a:1:{i:0;s:3:"ALL";}', 'editor'),
(3, 'a:13:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:5:"error";i:4;s:8:"products";i:5;s:5:"users";i:6;s:4:"logs";i:7;s:6:"orders";i:8;s:3:"acl";i:9;s:14:"searchSettings";i:10;s:7:"plugins";i:11;s:5:"index";i:12;s:6:"backup";}', 'a:7:{i:0;s:3:"new";i:1;s:4:"view";i:2;s:6:"update";i:3;s:6:"remove";i:4;s:7:"publish";i:5;s:7:"archive";i:6;s:3:"ALL";}', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_article_resource_type`
--

CREATE TABLE IF NOT EXISTS `zre_acl_article_resource_type` (
  `article_resource_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`article_resource_type_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zre_acl_article_resource_type`
--

INSERT INTO `zre_acl_article_resource_type` (`article_resource_type_id`, `type`) VALUES
(3, 'archive'),
(1, 'article'),
(4, 'download'),
(2, 'homepage'),
(5, 'support');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_deny`
--

CREATE TABLE IF NOT EXISTS `zre_acl_deny` (
  `acl_deny_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_deny_id`),
  KEY `name_id` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zre_acl_deny`
--

INSERT INTO `zre_acl_deny` (`acl_deny_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:6:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:7:"plugins";i:5;s:5:"index";}', 'a:1:{i:0;s:4:"view";}', 'guest');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_resource`
--

CREATE TABLE IF NOT EXISTS `zre_acl_resource` (
  `acl_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acl_resource_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `zre_acl_resource`
--

INSERT INTO `zre_acl_resource` (`acl_resource_id`, `name`, `parent`) VALUES
(1, 'administration', NULL),
(2, 'administration.index', 'administration'),
(3, 'articles', 'administration'),
(4, 'error', 'administration'),
(5, 'products', 'administration'),
(6, 'users', 'administration'),
(7, 'logs', 'administration'),
(8, 'orders', 'administration'),
(9, 'acl', 'administration'),
(10, 'searchSettings', 'administration'),
(11, 'plugins', 'administration'),
(12, 'index', NULL),
(13, 'backup', 'administration');

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_role`
--

CREATE TABLE IF NOT EXISTS `zre_acl_role` (
  `acl_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parents` text,
  PRIMARY KEY (`acl_role_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `zre_acl_role`
--

INSERT INTO `zre_acl_role` (`acl_role_id`, `name`, `parents`) VALUES
(1, 'guest', NULL),
(2, 'staff', 'a:1:{i:0;s:5:"guest";}'),
(3, 'editor', 'a:1:{i:0;s:5:"staff";}'),
(4, 'administrator', NULL),
(5, 'logs', '');

-- --------------------------------------------------------

--
-- Table structure for table `zre_article_container`
--

CREATE TABLE IF NOT EXISTS `zre_article_container` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Article containment structure.';

--
-- Dumping data for table `zre_article_container`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_article_content`
--

CREATE TABLE IF NOT EXISTS `zre_article_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL,
  `content` text,
  `use_zre_plugins` set('no','yes') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_article_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_article_content_comment`
--

CREATE TABLE IF NOT EXISTS `zre_article_content_comment` (
  `article_id` int(11) NOT NULL,
  `comment_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`article_id`),
  KEY `comment_date` (`comment_date`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of comments associated with an article node.';

--
-- Dumping data for table `zre_article_content_comment`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_article_node`
--

CREATE TABLE IF NOT EXISTS `zre_article_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) NOT NULL,
  `resource` text NOT NULL,
  `published` enum('no','yes','archived') NOT NULL DEFAULT 'no',
  `title` varchar(32) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  PRIMARY KEY (`id`),
  KEY `container_id` (`container_id`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='article nodes. article info without content.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_article_node`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_logs`
--

CREATE TABLE IF NOT EXISTS `zre_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders`
--

CREATE TABLE IF NOT EXISTS `zre_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_product_id` int(11) NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `order_property_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purchase_total` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_product_id` (`order_product_id`,`order_status_id`,`order_property_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_product`
--

CREATE TABLE IF NOT EXISTS `zre_orders_product` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zre_orders_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_property`
--

CREATE TABLE IF NOT EXISTS `zre_orders_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders_property`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_status`
--

CREATE TABLE IF NOT EXISTS `zre_orders_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_orders_status`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_plugin`
--

CREATE TABLE IF NOT EXISTS `zre_plugin` (
  `plugin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `settings` blob,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`plugin_id`),
  KEY `name` (`name`,`enabled`,`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zre_plugin`
--

INSERT INTO `zre_plugin` (`plugin_id`, `name`, `enabled`, `settings`, `position`) VALUES
(1, 'Menu_Main', 1, NULL, 'header'),
(2, 'Menu_Search', 0, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `zre_product_container`
--

CREATE TABLE IF NOT EXISTS `zre_product_container` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `description` varchar(256) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_product_container`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_product_content`
--

CREATE TABLE IF NOT EXISTS `zre_product_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL,
  `content` text,
  `use_zre_plugins` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_product_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_product_node`
--

CREATE TABLE IF NOT EXISTS `zre_product_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) NOT NULL,
  `published` enum('yes','no','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  `price` float NOT NULL,
  `weight` float NOT NULL,
  `size` float NOT NULL,
  `property_id` int(11) NOT NULL,
  `allotment` int(11) NOT NULL,
  `pending` int(11) NOT NULL,
  `sold` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `container_id` (`container_id`,`title`),
  KEY `price` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zre_product_node`
--


-- --------------------------------------------------------

--
-- Table structure for table `zre_users`
--

CREATE TABLE IF NOT EXISTS `zre_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` text NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User table.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zre_users`
--

INSERT INTO `zre_users` (`user_id`, `name`, `password`, `creation_date`) VALUES
(1, 'aalbino', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-08-04 17:23:01');

-- --------------------------------------------------------

--
-- Table structure for table `zre_users_profile`
--

CREATE TABLE IF NOT EXISTS `zre_users_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `country` text NOT NULL,
  `state_province` text NOT NULL,
  `city` text NOT NULL,
  `zipcode` text NOT NULL,
  `telephone_primary` text NOT NULL,
  `telephone_secondary` text,
  `role` enum('administrator','editor','staff','guest') NOT NULL DEFAULT 'guest',
  PRIMARY KEY (`user_profile_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User profile information.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zre_users_profile`
--

INSERT INTO `zre_users_profile` (`user_profile_id`, `user_id`, `email`, `date_of_birth`, `first_name`, `last_name`, `country`, `state_province`, `city`, `zipcode`, `telephone_primary`, `telephone_secondary`, `role`) VALUES
(1, 1, 'webmaster@alexventure.com', '1983-06-27', 'Alex', 'Albino', 'US', 'CA', 'Vallejo', '94590', '7072466864', '', 'administrator');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `zre_article_container`
--
ALTER TABLE `zre_article_container`
  ADD CONSTRAINT `zre_article_container_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `zre_article_container` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_article_content`
--
ALTER TABLE `zre_article_content`
  ADD CONSTRAINT `zre_article_content_ibfk_1` FOREIGN KEY (`node_id`) REFERENCES `zre_article_node` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_article_content_comment`
--
ALTER TABLE `zre_article_content_comment`
  ADD CONSTRAINT `zre_article_content_comment_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `zre_article_content` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_article_node`
--
ALTER TABLE `zre_article_node`
  ADD CONSTRAINT `zre_article_node_ibfk_1` FOREIGN KEY (`container_id`) REFERENCES `zre_article_container` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_product_container`
--
ALTER TABLE `zre_product_container`
  ADD CONSTRAINT `zre_product_container_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `zre_product_container` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_product_content`
--
ALTER TABLE `zre_product_content`
  ADD CONSTRAINT `zre_product_content_ibfk_1` FOREIGN KEY (`node_id`) REFERENCES `zre_product_node` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_product_node`
--
ALTER TABLE `zre_product_node`
  ADD CONSTRAINT `zre_product_node_ibfk_1` FOREIGN KEY (`container_id`) REFERENCES `zre_product_container` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_users_profile`
--
ALTER TABLE `zre_users_profile`
  ADD CONSTRAINT `zre_users_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `zre_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
