-- phpMyAdmin SQL Dump
-- version 3.3.7deb2build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 26, 2010 at 03:07 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_allow`
--

CREATE TABLE IF NOT EXISTS `zre_acl_allow` (
  `acl_allow_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_allow_id`),
  KEY `name_id` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_article_resource_type`
--

CREATE TABLE IF NOT EXISTS `zre_acl_article_resource_type` (
  `article_resource_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`article_resource_type_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_deny`
--

CREATE TABLE IF NOT EXISTS `zre_acl_deny` (
  `acl_deny_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_deny_id`),
  KEY `name_id` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_resource`
--

CREATE TABLE IF NOT EXISTS `zre_acl_resource` (
  `acl_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acl_resource_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_role`
--

CREATE TABLE IF NOT EXISTS `zre_acl_role` (
  `acl_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parents` text,
  PRIMARY KEY (`acl_role_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_article`
--

CREATE TABLE IF NOT EXISTS `zre_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_container_id` int(11) NOT NULL,
  `resource` text NOT NULL,
  `published` enum('no','yes','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  PRIMARY KEY (`article_id`),
  KEY `article_container_id` (`article_container_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='article info without content.' AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_article_container`
--

CREATE TABLE IF NOT EXISTS `zre_article_container` (
  `article_container_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`article_container_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Article containment structure.' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_images`
--

CREATE TABLE IF NOT EXISTS `zre_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_submitted` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `file` (`file`),
  KEY `date_submitted` (`date_submitted`),
  KEY `date_modified` (`date_modified`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Image records.' AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders`
--

CREATE TABLE IF NOT EXISTS `zre_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `decision` varchar(32) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` enum('pending','shipped','void','exchanged','refunded','awaiting_return','complete') NOT NULL DEFAULT 'pending',
  `merchant` varchar(32) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  KEY `merchant` (`merchant`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='order records' AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_cybersource`
--

CREATE TABLE IF NOT EXISTS `zre_orders_cybersource` (
  `orders_cybersource_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `reason_code` varchar(16) NOT NULL,
  `request_id` varchar(255) NOT NULL,
  `request_token` varchar(255) NOT NULL,
  `currency` varchar(16) NOT NULL,
  `cc_auth_blob` text NOT NULL,
  PRIMARY KEY (`orders_cybersource_id`),
  KEY `currency` (`currency`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_paypal`
--

CREATE TABLE IF NOT EXISTS `zre_orders_paypal` (
  `orders_paypal_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `transaction_id` int(32) NOT NULL,
  `correlation_id` varchar(32) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `version` varchar(8) NOT NULL,
  `build` int(11) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `avs_code` varchar(8) NOT NULL,
  `cvv2_match` varchar(8) NOT NULL,
  `time_stamp` datetime NOT NULL,
  `response_blob` text NOT NULL,
  PRIMARY KEY (`orders_paypal_id`),
  KEY `order_id` (`order_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `correlation_id` (`correlation_id`),
  KEY `decision` (`decision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_paypal_express`
--

CREATE TABLE IF NOT EXISTS `zre_orders_paypal_express` (
  `orders_paypal_express_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `token` varchar(32) NOT NULL,
  `timestamp` datetime NOT NULL,
  `correlation_id` varchar(32) NOT NULL,
  `decision` varchar(32) NOT NULL,
  `version` varchar(8) NOT NULL,
  `build` varchar(16) NOT NULL,
  `transaction_id` varchar(32) NOT NULL,
  `transaction_type` varchar(32) NOT NULL,
  `payment_type` varchar(32) NOT NULL,
  `order_time` datetime NOT NULL,
  `amt` float NOT NULL,
  `fee_amt` float NOT NULL,
  `tax_amt` float NOT NULL,
  `currency_code` varchar(3) NOT NULL,
  `payment_status` varchar(16) NOT NULL,
  `pending_reason` varchar(32) NOT NULL,
  `reason_code` varchar(32) NOT NULL,
  PRIMARY KEY (`orders_paypal_express_id`),
  UNIQUE KEY `order_id` (`order_id`),
  UNIQUE KEY `token` (`token`),
  KEY `transaction_id` (`transaction_id`),
  KEY `correlation_id` (`correlation_id`),
  KEY `decision` (`decision`),
  KEY `timestamp` (`timestamp`),
  KEY `payment_status` (`payment_status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_products`
--

CREATE TABLE IF NOT EXISTS `zre_orders_products` (
  `order_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`order_product_id`),
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`),
  KEY `unit_price` (`unit_price`,`quantity`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_plugin`
--

CREATE TABLE IF NOT EXISTS `zre_plugin` (
  `plugin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `settings` text,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`plugin_id`),
  KEY `name` (`name`,`enabled`,`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_product`
--

CREATE TABLE IF NOT EXISTS `zre_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT NULL,
  `published` enum('yes','no','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  `price` float NOT NULL,
  `weight` float NOT NULL,
  `size` float NOT NULL,
  `allotment` int(11) NOT NULL,
  `pending` int(11) NOT NULL,
  `sold` int(11) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_container_id` (`article_id`),
  KEY `title` (`title`),
  KEY `price` (`price`),
  KEY `weight` (`weight`),
  KEY `size` (`size`),
  KEY `allotment` (`allotment`),
  KEY `pending` (`pending`),
  KEY `sold` (`sold`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_product_options`
--

CREATE TABLE IF NOT EXISTS `zre_product_options` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`option_id`),
  KEY `product_id` (`product_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_users`
--

CREATE TABLE IF NOT EXISTS `zre_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `name` (`name`),
  KEY `active` (`active`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User table.' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_users_profile`
--

CREATE TABLE IF NOT EXISTS `zre_users_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(320) NOT NULL,
  `date_of_birth` date NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `country` varchar(2) NOT NULL,
  `state_province` varchar(2) NOT NULL,
  `city` varchar(64) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `telephone_primary` varchar(16) NOT NULL,
  `telephone_secondary` varchar(16) DEFAULT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`user_profile_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `role` (`role`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User profile information.' AUTO_INCREMENT=2 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `zre_article`
--
ALTER TABLE `zre_article`
  ADD CONSTRAINT `zre_article_ibfk_1` FOREIGN KEY (`article_container_id`) REFERENCES `zre_article_container` (`article_container_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_orders_cybersource`
--
ALTER TABLE `zre_orders_cybersource`
  ADD CONSTRAINT `zre_orders_cybersource_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `zre_orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_orders_paypal`
--
ALTER TABLE `zre_orders_paypal`
  ADD CONSTRAINT `zre_orders_paypal_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `zre_orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_orders_paypal_express`
--
ALTER TABLE `zre_orders_paypal_express`
  ADD CONSTRAINT `zre_orders_paypal_express_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `zre_orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_orders_products`
--
ALTER TABLE `zre_orders_products`
  ADD CONSTRAINT `zre_orders_products_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `zre_orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `zre_orders_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `zre_product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_product`
--
ALTER TABLE `zre_product`
  ADD CONSTRAINT `zre_product_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `zre_article` (`article_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zre_users_profile`
--
ALTER TABLE `zre_users_profile`
  ADD CONSTRAINT `zre_users_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `zre_users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `zre_users_profile_ibfk_2` FOREIGN KEY (`role`) REFERENCES `zre_acl_role` (`acl_role_id`) ON DELETE CASCADE ON UPDATE CASCADE;
