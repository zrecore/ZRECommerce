-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 02, 2010 at 11:37 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_allow`
--

CREATE TABLE IF NOT EXISTS `zre_acl_allow` (
  `acl_allow_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_allow_id`),
  KEY `name_id` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_article_resource_type`
--

CREATE TABLE IF NOT EXISTS `zre_acl_article_resource_type` (
  `article_resource_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`article_resource_type_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_deny`
--

CREATE TABLE IF NOT EXISTS `zre_acl_deny` (
  `acl_deny_id` int(11) NOT NULL AUTO_INCREMENT,
  `resources` text,
  `privileges` text,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`acl_deny_id`),
  KEY `name_id` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_resource`
--

CREATE TABLE IF NOT EXISTS `zre_acl_resource` (
  `acl_resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acl_resource_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_acl_role`
--

CREATE TABLE IF NOT EXISTS `zre_acl_role` (
  `acl_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parents` text,
  PRIMARY KEY (`acl_role_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_article`
--

CREATE TABLE IF NOT EXISTS `zre_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_container_id` int(11) NOT NULL,
  `resource` text NOT NULL,
  `published` enum('no','yes','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  PRIMARY KEY (`article_id`),
  KEY `article_container_id` (`article_container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='article info without content.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_article_container`
--

CREATE TABLE IF NOT EXISTS `zre_article_container` (
  `article_container_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(32) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`article_container_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Article containment structure.' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_images`
--

CREATE TABLE IF NOT EXISTS `zre_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `date_submitted` int(11) NOT NULL,
  `date_modified` int(11) NOT NULL,
  `file` int(11) NOT NULL,
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `file` (`file`),
  KEY `group_id` (`group_id`),
  KEY `date_submitted` (`date_submitted`),
  KEY `date_modified` (`date_modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Image records.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_logs`
--

CREATE TABLE IF NOT EXISTS `zre_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders`
--

CREATE TABLE IF NOT EXISTS `zre_orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `decision` varchar(32) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` enum('pending','shipped','void','exchanged','refunded','awaiting_return','complete') NOT NULL DEFAULT 'pending',
  `merchant` varchar(32) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  KEY `merchant` (`merchant`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='order records' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_cybersource`
--

CREATE TABLE IF NOT EXISTS `zre_orders_cybersource` (
  `orders_cybersource_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `decision` varchar(16) NOT NULL,
  `reason_code` varchar(16) NOT NULL,
  `request_id` varchar(255) NOT NULL,
  `request_token` varchar(255) NOT NULL,
  `currency` varchar(16) NOT NULL,
  `cc_auth_blob` text NOT NULL,
  PRIMARY KEY (`orders_cybersource_id`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_orders_products`
--

CREATE TABLE IF NOT EXISTS `zre_orders_products` (
  `order_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`order_product_id`),
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`),
  KEY `unit_price` (`unit_price`,`quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_plugin`
--

CREATE TABLE IF NOT EXISTS `zre_plugin` (
  `plugin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `settings` text,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`plugin_id`),
  KEY `name` (`name`,`enabled`,`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_product`
--

CREATE TABLE IF NOT EXISTS `zre_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT NULL,
  `published` enum('yes','no','archived') NOT NULL DEFAULT 'no',
  `title` varchar(128) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `image` text,
  `price` float NOT NULL,
  `weight` float NOT NULL,
  `size` float NOT NULL,
  `allotment` int(11) NOT NULL,
  `pending` int(11) NOT NULL,
  `sold` int(11) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_container_id` (`article_id`),
  KEY `title` (`title`),
  KEY `price` (`price`),
  KEY `weight` (`weight`),
  KEY `size` (`size`),
  KEY `allotment` (`allotment`),
  KEY `pending` (`pending`),
  KEY `sold` (`sold`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_users`
--

CREATE TABLE IF NOT EXISTS `zre_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User table.' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `zre_users_profile`
--

CREATE TABLE IF NOT EXISTS `zre_users_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `country` text NOT NULL,
  `state_province` text NOT NULL,
  `city` text NOT NULL,
  `zipcode` text NOT NULL,
  `telephone_primary` text NOT NULL,
  `telephone_secondary` text,
  `role` enum('administrator','editor','staff','guest') NOT NULL DEFAULT 'guest',
  PRIMARY KEY (`user_profile_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='User profile information.' AUTO_INCREMENT=2 ;
