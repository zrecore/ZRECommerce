-- phpMyAdmin SQL Dump
-- version 3.3.7deb3build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 05, 2011 at 07:46 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecommerce`
--

--
-- Dumping data for table `zre_acl_allow`
--

INSERT INTO `zre_acl_allow` (`acl_allow_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:9:{i:0;s:20:"administration.index";i:1;s:8:"articles";i:2;s:8:"products";i:3;s:6:"orders";i:4;s:5:"index";i:5;s:4:"logs";i:6;s:14:"administration";i:7;s:5:"users";i:8;s:3:"acl";}', 'a:1:{i:0;s:3:"ALL";}', 'staff'),
(2, 'a:5:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:5:"users";}', 'a:1:{i:0;s:3:"ALL";}', 'editor'),
(3, 'a:13:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:5:"error";i:4;s:8:"products";i:5;s:5:"users";i:6;s:4:"logs";i:7;s:6:"orders";i:8;s:3:"acl";i:9;s:14:"searchSettings";i:10;s:7:"plugins";i:11;s:5:"index";i:12;s:6:"backup";}', 'a:7:{i:0;s:3:"new";i:1;s:4:"view";i:2;s:6:"update";i:3;s:6:"remove";i:4;s:7:"publish";i:5;s:7:"archive";i:6;s:3:"ALL";}', 'administrator');

--
-- Dumping data for table `zre_acl_article_resource_type`
--

INSERT INTO `zre_acl_article_resource_type` (`article_resource_type_id`, `type`) VALUES
(3, 'archive'),
(1, 'article'),
(4, 'download'),
(2, 'homepage'),
(5, 'support');

--
-- Dumping data for table `zre_acl_deny`
--

INSERT INTO `zre_acl_deny` (`acl_deny_id`, `resources`, `privileges`, `name`) VALUES
(1, 'a:6:{i:0;s:14:"administration";i:1;s:20:"administration.index";i:2;s:8:"articles";i:3;s:8:"products";i:4;s:7:"plugins";i:5;s:5:"index";}', 'a:1:{i:0;s:4:"view";}', 'guest');

--
-- Dumping data for table `zre_acl_resource`
--

INSERT INTO `zre_acl_resource` (`acl_resource_id`, `name`, `parent`) VALUES
(1, 'administration', NULL),
(2, 'administration.index', 'administration'),
(3, 'articles', 'administration'),
(4, 'error', 'administration'),
(5, 'products', 'administration'),
(6, 'users', 'administration'),
(7, 'logs', 'administration'),
(8, 'orders', 'administration'),
(9, 'acl', 'administration'),
(10, 'searchSettings', 'administration'),
(11, 'plugins', 'administration'),
(12, 'index', NULL),
(13, 'backup', 'administration');

--
-- Dumping data for table `zre_acl_role`
--

INSERT INTO `zre_acl_role` (`acl_role_id`, `name`, `parents`) VALUES
(1, 'guest', NULL),
(2, 'staff', 'a:1:{i:0;s:5:"guest";}'),
(3, 'editor', 'a:1:{i:0;s:5:"staff";}'),
(4, 'administrator', NULL),
(5, 'logs', '');

--
-- Dumping data for table `zre_article`
--

INSERT INTO `zre_article` (`article_id`, `article_container_id`, `resource`, `published`, `title`, `description`, `date_created`, `date_modified`, `image`) VALUES
(1, 1, '', 'yes', 'Welcome', '<p>This is the welcome page.<br></p>', '2010-12-28 22:31:10', '2010-12-28 22:33:37', '/images/dummy.png');

--
-- Dumping data for table `zre_article_container`
--

INSERT INTO `zre_article_container` (`article_container_id`, `parent_id`, `order_weight`, `title`, `description`, `date`) VALUES
(1, NULL, 0, 'Main', 'The main category', '2010-08-11 22:08:01');

--
-- Dumping data for table `zre_images`
--

INSERT INTO `zre_images` (`image_id`, `date_submitted`, `date_modified`, `file`) VALUES
(7, '2010-12-21 22:59:03', '2010-12-21 22:59:03', 'dummy.png'),
(8, '2010-12-21 22:59:05', '2010-12-21 22:59:05', 'z.png'),
(15, '2010-12-22 02:30:50', '2010-12-22 02:30:50', 'tulips.jpg');

--
-- Dumping data for table `zre_orders`
--

INSERT INTO `zre_orders` (`order_id`, `decision`, `order_date`, `status`, `merchant`) VALUES
(1, 'Success', '2010-12-28 22:37:55', 'pending', 'paypalExpress'),
(2, 'Success', '2010-12-28 22:53:50', 'pending', 'paypalExpress'),
(3, 'Success', '2010-12-28 22:56:32', 'pending', 'paypalExpress'),
(4, 'Success', '2010-12-28 22:58:37', 'pending', 'paypalExpress'),
(5, 'Success', '2010-12-29 05:03:56', 'pending', 'paypalExpress'),
(6, 'Success', '2010-12-29 19:47:17', 'pending', 'paypalExpress');

--
-- Dumping data for table `zre_orders_cybersource`
--


--
-- Dumping data for table `zre_orders_paypal`
--


--
-- Dumping data for table `zre_orders_paypal_express`
--

INSERT INTO `zre_orders_paypal_express` (`orders_paypal_express_id`, `order_id`, `token`, `timestamp`, `correlation_id`, `decision`, `version`, `build`, `transaction_id`, `transaction_type`, `payment_type`, `order_time`, `amt`, `fee_amt`, `tax_amt`, `currency_code`, `payment_status`, `pending_reason`, `reason_code`) VALUES
(20, 1, 'EC-65U85244DA855281A', '2010-12-29 06:37:51', '2637aedfadabd', 'Success', '56.0', '1613703', '2BM32364K8051943V', 'expresscheckout', 'instant', '2010-12-29 06:37:51', 0.01, 0.01, 0, '', '', 'None', 'None'),
(21, 2, 'EC-0K026229U6539971R', '2010-12-29 06:53:46', '7e111c6185c23', 'Success', '56.0', '1613703', '8AV08147LR6101205', 'expresscheckout', 'instant', '2010-12-29 06:53:46', 0.01, 0.01, 0, '', '', 'None', 'None'),
(22, 3, 'EC-6YK91664FR290053T', '2010-12-29 06:56:28', 'a6b22b4bebd4a', 'Success', '56.0', '1613703', '7B308400KP9613825', 'expresscheckout', 'instant', '2010-12-29 06:56:27', 0.01, 0.01, 0, '', '', 'None', 'None'),
(23, 4, 'EC-1D423580L7459042G', '2010-12-29 06:58:34', '106b12df9a915', 'Success', '56.0', '1646991', '9F185432UP357615J', 'expresscheckout', 'instant', '2010-12-29 06:58:33', 0.01, 0.01, 0, '', '', 'None', 'None'),
(24, 5, 'EC-07U159941L984513A', '2010-12-29 13:03:51', 'd5b849d205bf', 'Success', '56.0', '1613703', '0YF84838WH577753M', 'expresscheckout', 'instant', '2010-12-29 13:03:51', 0.03, 0.03, 0, '', '', 'None', 'None'),
(25, 6, 'EC-3HX91341DG803281P', '2010-12-30 03:47:15', 'e9c0350ce614e', 'Success', '56.0', '1613703', '4B722552M5333411H', 'expresscheckout', 'instant', '2010-12-30 03:47:14', 0.01, 0.01, 0, '', '', 'None', 'None');

--
-- Dumping data for table `zre_orders_products`
--

INSERT INTO `zre_orders_products` (`order_product_id`, `order_id`, `product_id`, `unit_price`, `quantity`) VALUES
(20, 1, 1, 0.01, 1),
(21, 2, 1, 0.01, 1),
(22, 3, 1, 0.01, 1),
(23, 4, 1, 0.01, 1),
(24, 5, 1, 0.01, 3),
(25, 6, 1, 0.01, 1);

--
-- Dumping data for table `zre_plugin`
--

INSERT INTO `zre_plugin` (`plugin_id`, `name`, `enabled`, `settings`, `position`) VALUES
(1, 'Menu_Main', 1, NULL, 'header'),
(2, 'Menu_Search', 0, NULL, '');

--
-- Dumping data for table `zre_product`
--

INSERT INTO `zre_product` (`product_id`, `article_id`, `published`, `title`, `description`, `date_created`, `date_modified`, `image`, `price`, `weight`, `size`, `allotment`, `pending`, `sold`, `delivery_method`) VALUES
(1, NULL, 'yes', 'Product Download 1', '<p>This is a download.<br></p>', '2010-12-28 22:34:46', '2010-12-28 22:34:46', '/images/dummy.png', 0.01, 0, 0, 992, 0, 8, 'Download');

--
-- Dumping data for table `zre_product_options`
--

INSERT INTO `zre_product_options` (`option_id`, `product_id`, `key`, `value`) VALUES
(1, 1, 'download', 'test.mp3');

--
-- Dumping data for table `zre_product_pending`
--


--
-- Dumping data for table `zre_users`
--

INSERT INTO `zre_users` (`user_id`, `name`, `password`, `creation_date`, `active`) VALUES
(1, 'administrator', '5f4dcc3b5aa765d61d8327deb882cf99', '2010-12-15 00:15:26', 1);

--
-- Dumping data for table `zre_users_profile`
--

INSERT INTO `zre_users_profile` (`user_profile_id`, `user_id`, `email`, `date_of_birth`, `first_name`, `last_name`, `country`, `state_province`, `city`, `zipcode`, `telephone_primary`, `telephone_secondary`, `role`) VALUES
(1, 1, 'webmaster@localhost', '1980-01-01', 'System', 'Administrator', 'US', 'CA', 'San Francisco', '94109', '3215551234', NULL, 4);
SET FOREIGN_KEY_CHECKS=1;
