-- phpMyAdmin SQL Dump
-- version 3.3.7deb2build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 26, 2010 at 03:10 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zrecommerce`
--

--
-- Dumping data for table `zre_users_profile`
--

INSERT INTO `zre_users_profile` (`user_profile_id`, `user_id`, `email`, `date_of_birth`, `first_name`, `last_name`, `country`, `state_province`, `city`, `zipcode`, `telephone_primary`, `telephone_secondary`, `role`) VALUES
(1, 1, 'webmaster@localhost', '1980-01-01', 'System', 'Administrator', 'US', 'CA', 'San Francisco', '94109', '3215551234', NULL, 4);
SET FOREIGN_KEY_CHECKS=1;
